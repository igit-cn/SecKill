package com.proxy.entity;

public class ProxyListEntity {

    public int mapper_proxy_id;
    public String mapper_proxy_name;
    public int proxy_id;
    public String proxy_name;
    public int parent_proxy_id;
    public String parent_proxy_name;
    public int proxy_level;
    public long register_time;
    public int child_exist;
    public String remark;
}
