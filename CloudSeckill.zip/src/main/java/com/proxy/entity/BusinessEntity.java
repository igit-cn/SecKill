package com.proxy.entity;

public class BusinessEntity {
    
}
