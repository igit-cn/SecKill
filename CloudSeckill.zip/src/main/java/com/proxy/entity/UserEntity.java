package com.proxy.entity;

public class UserEntity {
    
    public int id;
    public String user_name;
    public int status;
    public long register_time;
    public String remark;
    public String email;
    public long use_time;
    
}
