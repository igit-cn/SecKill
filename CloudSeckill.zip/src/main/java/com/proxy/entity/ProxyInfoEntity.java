package com.proxy.entity;

public class ProxyInfoEntity {

    public int id;
    public String proxy_name;
    public int status;
    public String previous_proxy_name;
    public int previous_proxy_id ;
    public long register_time ;
    public String remark ;
    public String token;
    public int child_exist;
    public String parent_remark;
    public int proxy_level;
}
