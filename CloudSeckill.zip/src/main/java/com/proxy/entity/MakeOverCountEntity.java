package com.proxy.entity;


public class MakeOverCountEntity {
    
    public int type ;
    public int count;
    public long time;
    public String tips; 
}
