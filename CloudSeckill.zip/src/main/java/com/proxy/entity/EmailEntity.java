package com.proxy.entity;

public class EmailEntity {

    public int random_code;
    public long send_time;
    public String receive_email;
}
