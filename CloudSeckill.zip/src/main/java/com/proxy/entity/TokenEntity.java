package com.proxy.entity;

public class TokenEntity {

    public int proxy_id;
    public String proxy_name;
}
