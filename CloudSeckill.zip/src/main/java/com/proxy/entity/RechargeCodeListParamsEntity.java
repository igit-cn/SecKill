package com.proxy.entity;


public class RechargeCodeListParamsEntity {
    
    public String token;
    public String buyBeginTime; //create_time
    public String buyEndTime;
    public String sellBeginTime;//sell_time
    public String sellEndTime;
    public String rechargeBeginTime; //recharge_time
    public String rechargeEndTime;
    
    public String rechargeCode;
    public String remark;
    
    public String proxyName;
    public String rechargeType;
    public String status;
    public String affiliation;
    
}
