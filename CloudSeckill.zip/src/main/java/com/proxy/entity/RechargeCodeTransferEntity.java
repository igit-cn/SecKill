package com.proxy.entity;

public class RechargeCodeTransferEntity {
    
    public int id;
    public String recharge_code;
    public int recharge_code_type;
    public long transfer_time;
    public String remark;
    public String from_proxy_name;
    public String to_proxy_name;
}
