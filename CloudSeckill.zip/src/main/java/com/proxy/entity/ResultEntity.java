package com.proxy.entity;

public class ResultEntity {

    public String msg;
    public int code;
    public Object data;
}
