package com.proxy.entity;

import java.util.List;

public class ListEntity {
    
    public long total;
    public List list;
}
