package com.proxy.entity;

public class RechargeCodeTypeEntity {
    
    public int id ;
    public int type;
    public long create_time;
    public String tips;
    public long use_time;
}
