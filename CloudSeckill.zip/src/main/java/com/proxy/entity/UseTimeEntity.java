package com.proxy.entity;

public class UseTimeEntity {
    public long use_time; 
}
