package com.proxy.entity;

public class NullEntity {
    
}
