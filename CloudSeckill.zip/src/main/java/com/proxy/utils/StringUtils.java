package com.proxy.utils;

public class StringUtils {

    public static boolean isEmpty(String text){
        return text == null || "".equals(text);
    }

}
