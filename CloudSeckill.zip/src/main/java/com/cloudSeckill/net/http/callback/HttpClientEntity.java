package com.cloudSeckill.net.http.callback;


public class HttpClientEntity <T>{
    
    public String msg;
    public int resultCode;
    public String json ;
    public T entity;
}
