package com.cloudSeckill.service.inter;

import java.util.Random;
import java.util.UUID;

public abstract class DllInterfaceImpl implements DllInterface {
    private static String SEPARATOR_OF_MAC = ":";

    public static byte[] getRandomMac() {
        Random random = new Random();
        String[] mac = {
                String.format("%02x", 0x52),
                String.format("%02x", 0x54),
                String.format("%02x", 0x00),
                String.format("%02x", random.nextInt(0xff)),
                String.format("%02x", random.nextInt(0xff)),
                String.format("%02x", random.nextInt(0xff))
        };
        String macStr = String.join(SEPARATOR_OF_MAC, mac);
        return macStr.getBytes();
    }

    public static byte[] getRandomUUID() {
        return UUID.randomUUID().toString().getBytes();
    }
}
