package com.cloudSeckill.data.request;

/**
 * 登录参数
 */
public class LoginRequest {
    public String userName;//用户名
    public String userPass;//密码
}
