package com.cloudSeckill.data.request;

public class SearchGroupRequest {
    public String startTime;
    public String endTime;
}
