package com.cloudSeckill.data.request;

/**
 * 登录参数
 */
public class RegisterRequest {
    
    public String userName;
    public String userPass;
    public String userActiveCode;
    public String userEmail;
    public String validateCode;
    
}
