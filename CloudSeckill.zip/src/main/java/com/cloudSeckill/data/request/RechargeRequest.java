package com.cloudSeckill.data.request;

public class RechargeRequest {
    public String rechargeCode;
    public Integer id;
}
