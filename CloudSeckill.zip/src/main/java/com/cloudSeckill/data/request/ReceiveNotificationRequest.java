package com.cloudSeckill.data.request;

public class ReceiveNotificationRequest {
    
    public String WXUserId;
    public String type;
    
}
