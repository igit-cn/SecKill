package com.cloudSeckill.data.request;


public class WechatLogoutRequest {
    
    public String wechatId;
}
