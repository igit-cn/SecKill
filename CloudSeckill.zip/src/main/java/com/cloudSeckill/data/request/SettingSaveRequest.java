package com.cloudSeckill.data.request;

public class SettingSaveRequest {
    public Integer id;
    public Integer pickType;
    public Integer pickDelay;
    public Integer pickDelayTime;
    public Integer autoPickPersonal;
    public Integer autoReceiveTransafer;
}
