package com.cloudSeckill.data.request;

public class RemoveItemRequest {
    public int id;
}
