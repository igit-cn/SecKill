package com.cloudSeckill.data.request;

public class ConfirmMemberRequest {
    public String memberArrayStr;
}
