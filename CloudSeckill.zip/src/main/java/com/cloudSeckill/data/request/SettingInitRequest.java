package com.cloudSeckill.data.request;

public class SettingInitRequest {
    public Integer id;
}
