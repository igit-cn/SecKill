package com.cloudSeckill.data.request;

public class SendEmailRequest {
    
    public String userName;
    public String email;
    
}
