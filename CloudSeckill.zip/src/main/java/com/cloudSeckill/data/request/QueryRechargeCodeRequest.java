package com.cloudSeckill.data.request;


public class QueryRechargeCodeRequest {

    public String verifyCode;
    public String rechargeCode;
}
