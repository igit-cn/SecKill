package com.cloudSeckill.data.response;

public class HearBeatBean {
    public int status ;
    
}
