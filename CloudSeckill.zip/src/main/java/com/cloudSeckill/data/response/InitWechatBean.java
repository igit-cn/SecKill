package com.cloudSeckill.data.response;

public class InitWechatBean {
    public int state;
    public String object;
    
}
