package com.cloudSeckill.data.response;

public class DataInfoBean {
    
    public int sub_type;
    public String content;
    public String to_user;
    public String from_user;
    public String description;
    
    public String msg_id;
}
