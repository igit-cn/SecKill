package com.cloudSeckill.data.response;

public class QueryRechargeCodeStatusBean {
    
    public String type;
    public String status;
}
