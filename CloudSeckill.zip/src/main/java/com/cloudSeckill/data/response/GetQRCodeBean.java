package com.cloudSeckill.data.response;

public class GetQRCodeBean {
    public String qr_code;
}
