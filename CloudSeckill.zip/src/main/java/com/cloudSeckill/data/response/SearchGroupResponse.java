package com.cloudSeckill.data.response;


public class SearchGroupResponse {
    
    public String groupName ;
    public String groupId ;
    public int count ;
    public int money ;
}
