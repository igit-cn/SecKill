package com.cloudSeckill.data.response;

public class ReceiveRedPacketBean {
    public String key;
    public int status;
    
}
