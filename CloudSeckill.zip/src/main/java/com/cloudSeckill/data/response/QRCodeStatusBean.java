package com.cloudSeckill.data.response;

public class QRCodeStatusBean {
    public String device_type;
    public int expired_time;
    public String head_url;
    public String nick_name;
    public String password;
    public int status;
    public String user_name;
    
}
