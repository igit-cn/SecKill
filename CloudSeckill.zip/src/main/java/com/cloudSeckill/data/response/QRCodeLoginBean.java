package com.cloudSeckill.data.response;

public class QRCodeLoginBean {
    public int status = -1;
    
}
