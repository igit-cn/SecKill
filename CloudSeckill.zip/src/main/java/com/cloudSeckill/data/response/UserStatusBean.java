package com.cloudSeckill.data.response;

public class UserStatusBean {
    public String user_name;
    
}
