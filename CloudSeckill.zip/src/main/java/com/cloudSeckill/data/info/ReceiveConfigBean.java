package com.cloudSeckill.data.info;

import com.cloudSeckill.dao.domain.User;

import java.util.Date;

public class ReceiveConfigBean {
    
    public int userId;
    public String wechatId;
    public Date time;
    
    public User user;
    
}
