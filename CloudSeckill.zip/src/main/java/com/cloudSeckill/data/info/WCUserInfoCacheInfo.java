package com.cloudSeckill.data.info;

/**
 * wc用户相关缓存
 */
public class WCUserInfoCacheInfo {

    public String wc_user_id;
    public String web_user_name;
    public long points;
    public String wc_user_name;
    public String wc_head_url;
    public boolean is_manager;
    public boolean is_entrust;
    public boolean is_blackList;
    public String inviterUserName;
    
}