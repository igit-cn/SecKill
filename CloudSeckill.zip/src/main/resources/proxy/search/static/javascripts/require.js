var _scriptFile = '<script src="static/javascripts/zepto.min.js"></script>'+
    '<script src="static/javascripts/simpleui.min.js"></script>'+
    '<script src="static/javascripts/common.js"></script>'+
    '<script src="static/javascripts/net.js"></script>'+
    '<link href="static/stylesheets/simpleui.min.css" rel="stylesheet" type="text/css">'+
    '<link href="static/stylesheets/common.css" rel="stylesheet" type="text/css">';

document.write(_scriptFile);