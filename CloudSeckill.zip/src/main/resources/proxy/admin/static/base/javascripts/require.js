// 导入常用的样式和脚本
var _CSS_PATH_ = '' +
'<link href="static/jquery-ui/jquery-ui.min.css" rel="stylesheet" type="text/css">'+
'<link href="static/base/stylesheets/common.css" rel="stylesheet" type="text/css">'+
'<link href="static/dialog/jquery.dialog.css" rel="stylesheet" type="text/css">'+
'<link href="static/pagger/jquery.pager.css" rel="stylesheet" type="text/css">'+
'<link href="static/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">';

var _JS_PATH_ = ''+
'<script src="static/base/javascripts/jquery-1.12.3.min.js"></script>'+
'<script src="static/base/javascripts/md5.min.js"></script>'+
'<script src="static/jquery-ui/jquery-ui.min.js"></script>'+
'<script src="static/base/javascripts/base64.min.js"></script>'+
'<script src="static/store/store.legacy.min.js"></script>'+
'<script src="static/base/javascripts/jquery.cookie.min.js"></script>'+
'<script src="static/purl/jquery.purl.min.js"></script>'+
'<script src="static/jquery.form/jquery.form.min.js"></script>'+
'<script src="static/dialog/jquery.dialog.js"></script>'+
'<script src="static/base/javascripts/jquery.icheck.min.js"></script>'+
'<script src="static/my97/WdatePicker.js"></script>'+
'<script src="static/pagger/jquery.pager.min.js"></script>'+
'<script src="static/base/javascripts/jquery.slimscroll.min.js"></script>';

document.write(_CSS_PATH_ + _JS_PATH_);