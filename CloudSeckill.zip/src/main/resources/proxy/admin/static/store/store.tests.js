// store-com.test-suite will run all the store.js tests
// and report the results.

var tests = require('../tests/tests')

tests.runTests()
