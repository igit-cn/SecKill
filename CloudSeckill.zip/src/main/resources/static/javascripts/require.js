var _scriptFile = '' +
    '<script src="javascripts/zepto.min.js"></script>'+
    '<script src="javascripts/simpleui.min.js"></script>'+
    '<script src="javascripts/common.js"></script>'+
    '<script src="javascripts/net.js"></script>'+
    '<link href="stylesheets/simpleui.min.css" rel="stylesheet" type="text/css">'+
    '<link href="stylesheets/common.css" rel="stylesheet" type="text/css">';

document.write(_scriptFile);